"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Hammer, Leaf, Heart, Sparkles } from "lucide-react"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"

const features = [
  {
    icon: Hammer,
    title: "Handcrafted",
    description: "Each piece made with traditional techniques",
  },
  {
    icon: Leaf,
    title: "Sustainable",
    description: "Responsibly sourced British hardwood",
  },
  {
    icon: Heart,
    title: "Made with Love",
    description: "Passion in every detail",
  },
  {
    icon: Sparkles,
    title: "Unique",
    description: "No two pieces are exactly alike",
  },
]

export function CraftsmanshipSection() {
  const imageAnim = useScrollAnimation({ direction: "right", delay: 0 })
  const contentAnim = useScrollAnimation({ direction: "left", delay: 200 })
  const badgeAnim = useScrollAnimation({ direction: "rotate", delay: 400 })

  return (
    <section id="our-story" className="py-24 relative overflow-hidden bg-muted/30">
      {/* Background effect */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -translate-y-1/2" />
      <div className="absolute top-1/3 right-0 w-72 h-72 bg-secondary/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image Side */}
          <div ref={imageAnim.ref} className={`relative ${imageAnim.className}`}>
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
              <Image
                src="/craftsman-working-on-colorful-wooden-furniture-in-.jpg"
                alt="Craftsman at work"
                fill
                className="object-cover"
              />
              {/* Floating badge */}
              <div
                ref={badgeAnim.ref}
                className={`absolute -right-4 -bottom-4 md:right-8 md:bottom-8 bg-white rounded-2xl p-6 shadow-xl border border-border ${badgeAnim.className}`}
              >
                <div className="text-center">
                  <span className="block text-4xl font-bold gradient-text">15+</span>
                  <span className="text-sm text-foreground/60">Years of Craft</span>
                </div>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-4 -left-4 w-24 h-24 border-2 border-primary/30 rounded-2xl" />
          </div>

          {/* Content Side */}
          <div ref={contentAnim.ref} className={`lg:pl-8 ${contentAnim.className}`}>
            <span className="text-primary text-sm uppercase tracking-widest font-semibold">Design Led</span>
            <h2 className="font-[var(--font-display)] text-4xl md:text-5xl font-bold mt-4 mb-6">
              British <span className="gradient-text">Craftsmanship</span>
            </h2>
            <p className="text-foreground/60 leading-relaxed mb-6">
              We make furniture the old-fashioned way. Each made-to-order piece celebrates the natural beauty of
              hardwood, with design twists that add personality and a modern edge.
            </p>
            <p className="text-foreground/60 leading-relaxed mb-8">
              Our workshop in the heart of Britain is where tradition meets creativity. Every curve, every color, every
              detail is considered with care.
            </p>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-6 mb-8">
              {features.map((feature, index) => (
                <FeatureItem key={index} feature={feature} index={index} />
              ))}
            </div>

            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/25">
              Discover Our Process
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

function FeatureItem({ feature, index }: { feature: (typeof features)[0]; index: number }) {
  const anim = useScrollAnimation({ direction: "up", delay: 400 + index * 100 })

  return (
    <div ref={anim.ref} className={`flex items-start gap-3 ${anim.className}`}>
      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
        <feature.icon className="w-5 h-5 text-primary" />
      </div>
      <div>
        <h4 className="font-medium text-foreground">{feature.title}</h4>
        <p className="text-sm text-foreground/60">{feature.description}</p>
      </div>
    </div>
  )
}
