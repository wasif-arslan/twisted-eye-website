"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ShoppingBag, Heart, Eye } from "lucide-react"
import { useCart } from "@/components/cart-context"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"

const products = [
  {
    id: 1,
    name: "Cityfarm Hardwood Dining Table",
    price: 1400,
    image: "/colorful-rustic-wooden-dining-table-with-pink-legs.jpg",
    category: "Tables",
    colors: ["#f472b6", "#22d3d1", "#a3e635"],
  },
  {
    id: 2,
    name: "Vibrant Colpop Dining Table",
    price: 1600,
    image: "/vibrant-colorful-wooden-table-with-painted-legs-or.jpg",
    category: "Tables",
    colors: ["#fb923c", "#fcd34d", "#22d3d1"],
  },
  {
    id: 3,
    name: "Cityfarm Seat Side Table",
    price: 650,
    image: "/rustic-wooden-side-table-with-colorful-painted-det.jpg",
    category: "Side Tables",
    colors: ["#a78bfa", "#f472b6", "#a3e635"],
  },
  {
    id: 4,
    name: "Colpop Side Table with Shelf",
    price: 610,
    image: "/colorful-painted-wooden-side-table-with-shelf-oran.jpg",
    category: "Side Tables",
    colors: ["#fb923c", "#22d3d1", "#fcd34d"],
  },
]

export function ProductShowcase() {
  const [hoveredProduct, setHoveredProduct] = useState<number | null>(null)
  const { addItem } = useCart()

  const headerAnim = useScrollAnimation({ direction: "down", delay: 0 })
  const descAnim = useScrollAnimation({ direction: "up", delay: 150 })

  return (
    <section id="shop" className="py-24 relative bg-muted/30">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-background to-transparent" />

      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <span
            ref={headerAnim.ref}
            className={`text-primary text-sm uppercase tracking-widest font-semibold ${headerAnim.className}`}
          >
            Shop the Look
          </span>
          <h2
            ref={descAnim.ref}
            className={`font-[var(--font-display)] text-4xl md:text-5xl font-bold mt-4 mb-6 ${descAnim.className}`}
          >
            Featured <span className="gradient-text">Curiosities</span>
          </h2>
          <p className="text-foreground/60 max-w-xl mx-auto leading-relaxed">
            Each piece tells a story. Handcrafted with passion, designed with a twist.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <ProductCard
              key={product.id}
              product={product}
              index={index}
              isHovered={hoveredProduct === product.id}
              onHover={() => setHoveredProduct(product.id)}
              onLeave={() => setHoveredProduct(null)}
              onAddToCart={() =>
                addItem({ id: product.id, name: product.name, price: product.price, image: product.image })
              }
            />
          ))}
        </div>

        <div className="text-center mt-12">
          <Button
            variant="outline"
            size="lg"
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
          >
            View All Products
          </Button>
        </div>
      </div>
    </section>
  )
}

function ProductCard({
  product,
  index,
  isHovered,
  onHover,
  onLeave,
  onAddToCart,
}: {
  product: (typeof products)[0]
  index: number
  isHovered: boolean
  onHover: () => void
  onLeave: () => void
  onAddToCart: () => void
}) {
  // Alternate directions: left for even, right for odd
  const direction = index % 2 === 0 ? "left" : "right"
  const anim = useScrollAnimation({ direction, delay: index * 100 })

  return (
    <Card
      ref={anim.ref}
      className={`group relative bg-card border-border overflow-hidden cursor-pointer transition-all duration-500 hover:border-primary/50 hover:shadow-xl hover:shadow-primary/10 ${anim.className}`}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
    >
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden bg-muted">
        <Image
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-110"
        />

        {/* Overlay */}
        <div
          className={`absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center gap-3 transition-opacity duration-300 ${isHovered ? "opacity-100" : "opacity-0"}`}
        >
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full bg-foreground/10 hover:bg-primary hover:text-primary-foreground"
          >
            <Eye className="w-4 h-4" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full bg-foreground/10 hover:bg-primary hover:text-primary-foreground"
          >
            <Heart className="w-4 h-4" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full bg-foreground/10 hover:bg-primary hover:text-primary-foreground"
            onClick={onAddToCart}
          >
            <ShoppingBag className="w-4 h-4" />
          </Button>
        </div>

        {/* Color dots */}
        <div className="absolute bottom-3 left-3 flex gap-1.5">
          {product.colors.map((color, i) => (
            <div
              key={i}
              className="w-4 h-4 rounded-full border-2 border-white shadow-sm"
              style={{ backgroundColor: color }}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <span className="text-xs text-primary uppercase tracking-wider font-semibold">{product.category}</span>
        <h3 className="font-medium mt-1 mb-2 group-hover:text-primary transition-colors">{product.name}</h3>
        <p className="text-lg font-semibold text-foreground">from £{product.price.toLocaleString()}</p>
      </div>
    </Card>
  )
}
