"use client"

import { useEffect, useRef, useState } from "react"

type AnimationDirection = "up" | "down" | "left" | "right" | "scale" | "rotate"

interface UseScrollAnimationOptions {
  threshold?: number
  delay?: number
  direction?: AnimationDirection
}

export function useScrollAnimation<T extends HTMLElement = HTMLDivElement>({
  threshold = 0.1,
  delay = 0,
  direction = "up",
}: UseScrollAnimationOptions = {}) {
  const ref = useRef<T>(null)
  const [isInView, setIsInView] = useState(false)

  useEffect(() => {
    const element = ref.current
    if (!element) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => {
            setIsInView(true)
          }, delay)
          observer.unobserve(element)
        }
      },
      { threshold },
    )

    observer.observe(element)

    return () => {
      observer.disconnect()
    }
  }, [threshold, delay])

  const directionClass = {
    up: "scroll-fade-up",
    down: "scroll-fade-down",
    left: "scroll-fade-left",
    right: "scroll-fade-right",
    scale: "scroll-scale",
    rotate: "scroll-rotate",
  }[direction]

  return {
    ref,
    className: `scroll-animate ${directionClass} ${isInView ? "in-view" : ""}`,
  }
}
