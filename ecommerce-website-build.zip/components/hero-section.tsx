"use client"

import { useRef } from "react"
import { Button } from "@/components/ui/button"
import { ArrowDown, Sparkles } from "lucide-react"
import { FloatingFurniture } from "@/components/floating-furniture"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"

export function HeroSection() {
  const containerRef = useRef<HTMLDivElement>(null)

  const badgeAnim = useScrollAnimation({ direction: "down", delay: 100 })
  const titleAnim = useScrollAnimation({ direction: "up", delay: 200 })
  const subtitleAnim = useScrollAnimation({ direction: "up", delay: 400 })
  const buttonsAnim = useScrollAnimation({ direction: "scale", delay: 600 })

  return (
    <section
      ref={containerRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-32"
    >
      <div className="absolute inset-0 pointer-events-none">
        {/* Gradient orbs - softer for light theme */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/15 rounded-full blur-3xl animate-glow-pulse" />
        <div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-secondary/15 rounded-full blur-3xl animate-glow-pulse"
          style={{ animationDelay: "2s" }}
        />
        <div
          className="absolute top-1/2 left-1/2 w-64 h-64 bg-accent/10 rounded-full blur-3xl animate-glow-pulse"
          style={{ animationDelay: "4s" }}
        />

        {/* Sparkles */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-primary rounded-full animate-sparkle"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      {/* Floating 3D Elements */}
      <FloatingFurniture />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div
          ref={badgeAnim.ref}
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8 ${badgeAnim.className}`}
        >
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-sm text-foreground/70 font-medium">Museum of Curiosities</span>
        </div>

        <h1
          ref={titleAnim.ref}
          className={`font-[var(--font-display)] text-5xl md:text-7xl lg:text-8xl font-bold mb-6 ${titleAnim.className}`}
        >
          <span className="block text-foreground">Furniture with a</span>
          <span className="block gradient-text">Joyful Twist</span>
        </h1>

        <p
          ref={subtitleAnim.ref}
          className={`text-lg md:text-xl text-foreground/60 max-w-2xl mx-auto mb-10 leading-relaxed ${subtitleAnim.className}`}
        >
          Each piece is handcrafted with love, celebrating the natural beauty of hardwood with design twists that add
          personality and a modern edge.
        </p>

        <div
          ref={buttonsAnim.ref}
          className={`flex flex-col sm:flex-row items-center justify-center gap-4 ${buttonsAnim.className}`}
        >
          <Button
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-lg group shadow-lg shadow-primary/25"
          >
            Explore Collection
            <ArrowDown className="ml-2 w-5 h-5 group-hover:translate-y-1 transition-transform" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-foreground/20 text-foreground hover:bg-foreground/5 px-8 py-6 text-lg bg-transparent"
          >
            Our Process
          </Button>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
          <span className="text-xs text-foreground/50 uppercase tracking-widest">Scroll</span>
          <div className="w-6 h-10 rounded-full border-2 border-foreground/20 flex items-start justify-center p-2">
            <div className="w-1 h-2 bg-primary rounded-full animate-pulse" />
          </div>
        </div>
      </div>
    </section>
  )
}
