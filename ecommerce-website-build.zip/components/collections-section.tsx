"use client"

import Image from "next/image"
import { ArrowRight } from "lucide-react"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"

const collections = [
  {
    id: 1,
    name: "Vibrant Rustic",
    description: "Country style with a joyful twist",
    image: "/rustic-farmhouse-interior-with-colorful-furniture.jpg",
    count: 12,
  },
  {
    id: 2,
    name: "Urban Pop",
    description: "Bold colors meet modern design",
    image: "/modern-colorful-furniture-in-urban-loft.jpg",
    count: 8,
  },
  {
    id: 3,
    name: "Natural Twist",
    description: "Organic forms with playful accents",
    image: "/natural-wood-furniture-with-painted-colorful-detai.jpg",
    count: 15,
  },
]

export function CollectionsSection() {
  const headerAnim = useScrollAnimation({ direction: "right", delay: 0 })
  const descAnim = useScrollAnimation({ direction: "left", delay: 100 })

  return (
    <section id="collections" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-16 gap-4">
          <div ref={headerAnim.ref} className={headerAnim.className}>
            <span className="text-primary text-sm uppercase tracking-widest font-semibold">Curated</span>
            <h2 className="font-[var(--font-display)] text-4xl md:text-5xl font-bold mt-4">
              Our <span className="gradient-text">Collections</span>
            </h2>
          </div>
          <p ref={descAnim.ref} className={`text-foreground/60 max-w-md leading-relaxed ${descAnim.className}`}>
            Explore our carefully curated collections, each with its own unique personality and charm.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {collections.map((collection, index) => (
            <CollectionCard key={collection.id} collection={collection} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}

function CollectionCard({ collection, index }: { collection: (typeof collections)[0]; index: number }) {
  const anim = useScrollAnimation({ direction: "scale", delay: index * 150 })

  return (
    <div
      ref={anim.ref}
      className={`group relative aspect-[3/4] rounded-2xl overflow-hidden cursor-pointer shadow-lg ${anim.className}`}
    >
      <Image
        src={collection.image || "/placeholder.svg"}
        alt={collection.name}
        fill
        className="object-cover transition-transform duration-700 group-hover:scale-110"
      />

      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

      {/* Content */}
      <div className="absolute inset-x-0 bottom-0 p-6">
        <span className="text-sm text-white/80">{collection.count} pieces</span>
        <h3 className="font-[var(--font-display)] text-2xl font-bold mt-1 mb-2 text-white group-hover:text-primary transition-colors">
          {collection.name}
        </h3>
        <p className="text-white/70 text-sm mb-4">{collection.description}</p>
        <div className="flex items-center gap-2 text-primary opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
          <span className="text-sm font-medium">Explore</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>

      {/* Hover glow */}
      <div className="absolute inset-0 border-2 border-primary/0 group-hover:border-primary rounded-2xl transition-colors duration-300" />
    </div>
  )
}
