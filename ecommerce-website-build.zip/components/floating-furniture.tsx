"use client"

interface FurnitureItem {
  id: number
  x: number
  y: number
  rotation: number
  scale: number
  delay: number
  color: string
  type: "table" | "chair" | "shelf"
}

const furnitureItems: FurnitureItem[] = [
  { id: 1, x: 10, y: 20, rotation: -15, scale: 0.8, delay: 0, color: "#f472b6", type: "table" },
  { id: 2, x: 80, y: 15, rotation: 10, scale: 0.7, delay: 1, color: "#22d3d1", type: "chair" },
  { id: 3, x: 15, y: 70, rotation: 5, scale: 0.6, delay: 2, color: "#a3e635", type: "shelf" },
  { id: 4, x: 85, y: 65, rotation: -8, scale: 0.75, delay: 0.5, color: "#fb923c", type: "table" },
  { id: 5, x: 5, y: 45, rotation: 12, scale: 0.5, delay: 1.5, color: "#a78bfa", type: "chair" },
  { id: 6, x: 92, y: 40, rotation: -5, scale: 0.55, delay: 2.5, color: "#fcd34d", type: "shelf" },
]

function TableIcon({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 100 80" className="w-full h-full">
      <rect x="10" y="10" width="80" height="8" rx="2" fill={color} />
      <rect x="15" y="18" width="6" height="52" rx="1" fill={color} opacity="0.8" />
      <rect x="79" y="18" width="6" height="52" rx="1" fill={color} opacity="0.8" />
      <ellipse cx="50" cy="8" rx="35" ry="3" fill={color} opacity="0.3" />
    </svg>
  )
}

function ChairIcon({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 60 80" className="w-full h-full">
      <rect x="5" y="5" width="50" height="45" rx="3" fill={color} />
      <rect x="10" y="50" width="5" height="25" rx="1" fill={color} opacity="0.8" />
      <rect x="45" y="50" width="5" height="25" rx="1" fill={color} opacity="0.8" />
      <rect x="10" y="5" width="40" height="8" rx="2" fill={color} opacity="0.6" />
    </svg>
  )
}

function ShelfIcon({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 80 60" className="w-full h-full">
      <rect x="0" y="0" width="80" height="8" rx="2" fill={color} />
      <rect x="0" y="26" width="80" height="8" rx="2" fill={color} />
      <rect x="0" y="52" width="80" height="8" rx="2" fill={color} />
      <rect x="5" y="8" width="4" height="44" rx="1" fill={color} opacity="0.7" />
      <rect x="71" y="8" width="4" height="44" rx="1" fill={color} opacity="0.7" />
    </svg>
  )
}

export function FloatingFurniture() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {furnitureItems.map((item) => (
        <div
          key={item.id}
          className="absolute transition-transform duration-1000"
          style={{
            left: `${item.x}%`,
            top: `${item.y}%`,
            transform: `rotate(${item.rotation}deg) scale(${item.scale})`,
            animation: `float ${6 + item.delay}s ease-in-out infinite`,
            animationDelay: `${item.delay}s`,
            opacity: 0.85, // Increased opacity for light theme visibility
          }}
        >
          <div className="w-20 h-16 md:w-28 md:h-24 relative">
            <div
              className="absolute inset-0 blur-2xl rounded-full"
              style={{ backgroundColor: item.color, opacity: 0.4 }}
            />
            <div
              className="absolute inset-0 blur-md rounded-full translate-y-2"
              style={{ backgroundColor: "rgba(0,0,0,0.1)" }}
            />
            {/* Icon */}
            <div className="relative z-10 drop-shadow-lg">
              {item.type === "table" && <TableIcon color={item.color} />}
              {item.type === "chair" && <ChairIcon color={item.color} />}
              {item.type === "shelf" && <ShelfIcon color={item.color} />}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
