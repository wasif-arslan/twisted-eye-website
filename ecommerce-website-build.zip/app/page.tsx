import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { ProductShowcase } from "@/components/product-showcase"
import { CollectionsSection } from "@/components/collections-section"
import { CraftsmanshipSection } from "@/components/craftsmanship-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { Footer } from "@/components/footer"
import { CartProvider } from "@/components/cart-context"

export default function HomePage() {
  return (
    <CartProvider>
      <div className="min-h-screen bg-background overflow-hidden">
        <Header />
        <main>
          <HeroSection />
          <ProductShowcase />
          <CollectionsSection />
          <CraftsmanshipSection />
          <TestimonialsSection />
        </main>
        <Footer />
      </div>
    </CartProvider>
  )
}
