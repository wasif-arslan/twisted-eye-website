"use client"

import { useState } from "react"
import { Quote, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"

const testimonials = [
  {
    id: 1,
    quote: "Playful, vibrant, and bizarrely compelling. The craftsmanship is exceptional.",
    author: "Design Magazine",
    role: "Featured Review",
  },
  {
    id: 2,
    quote: "Finally, furniture that doesn't take itself too seriously. Absolutely love our dining table!",
    author: "Sarah M.",
    role: "Happy Customer",
  },
  {
    id: 3,
    quote: "Each piece is a conversation starter. The quality matches the creativity.",
    author: "Interiors Today",
    role: "Editor's Pick",
  },
]

export function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const headerAnim = useScrollAnimation({ direction: "down", delay: 0 })
  const quoteAnim = useScrollAnimation({ direction: "scale", delay: 200 })

  const next = () => setCurrentIndex((i) => (i + 1) % testimonials.length)
  const prev = () => setCurrentIndex((i) => (i - 1 + testimonials.length) % testimonials.length)

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <span
            ref={headerAnim.ref}
            className={`text-primary text-sm uppercase tracking-widest font-semibold ${headerAnim.className}`}
          >
            Recognition
          </span>

          <div ref={quoteAnim.ref} className={`relative py-12 ${quoteAnim.className}`}>
            <Quote className="w-12 h-12 text-primary/30 mx-auto mb-6" />

            <div className="overflow-hidden">
              <div
                className="flex transition-transform duration-500 ease-out"
                style={{ transform: `translateX(-${currentIndex * 100}%)` }}
              >
                {testimonials.map((testimonial) => (
                  <div key={testimonial.id} className="w-full flex-shrink-0 px-4">
                    <blockquote className="font-[var(--font-display)] text-2xl md:text-3xl font-medium mb-6 leading-relaxed text-foreground">
                      {'"'}
                      {testimonial.quote}
                      {'"'}
                    </blockquote>
                    <div>
                      <div className="font-semibold text-foreground">{testimonial.author}</div>
                      <div className="text-sm text-foreground/60">{testimonial.role}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <Button
                variant="outline"
                size="icon"
                className="rounded-full border-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
                onClick={prev}
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <div className="flex gap-2">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      i === currentIndex ? "bg-primary" : "bg-primary/30"
                    }`}
                    onClick={() => setCurrentIndex(i)}
                  />
                ))}
              </div>
              <Button
                variant="outline"
                size="icon"
                className="rounded-full border-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
                onClick={next}
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
